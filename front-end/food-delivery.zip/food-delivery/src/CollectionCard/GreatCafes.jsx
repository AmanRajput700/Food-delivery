import React from 'react'

const GreatCafes = () => {
  return (
    <div>GreatCafes</div>
  )
}

export default GreatCafes