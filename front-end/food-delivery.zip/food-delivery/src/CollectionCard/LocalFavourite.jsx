import React from 'react'

const LocalFavourite = () => {
  return (
    <div>LocalFavourite</div>
  )
}

export default LocalFavourite