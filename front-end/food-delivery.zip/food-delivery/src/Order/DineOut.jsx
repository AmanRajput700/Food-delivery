import React from 'react'
import MainNav from '../Components/Navbar/MainNav'
import Tablist from '../Components/OrderOnline/Tablist'
const DineOut = () => {
  return (
    <div>
      {/* <MainNav /> */}
      {/* <Tablist /> */}
      this is the dine out page
    </div>
  )
}

export default DineOut