import React from "react";

export default function Heading(){
    return(
        <div>
            <h1 className="text-large text-center m-1 font-[Montserrat] font-extrabold heading">Urban Eats</h1>
        </div>
    )
}