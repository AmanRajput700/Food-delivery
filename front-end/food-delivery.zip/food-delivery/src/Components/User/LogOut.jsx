import React, { useContext } from 'react'
import axios from 'axios';


const LogOut = ()=>{
    
}

export default LogOut;